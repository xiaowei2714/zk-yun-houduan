import{x as e,o as t,a as c}from"./index-B5ZZiHj2.js";const o={},n={class:"page-mate"};function s(a,r){return t(),c("div",n)}const f=e(o,[["render",s]]);export{f as default};
