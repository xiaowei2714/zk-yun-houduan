import{i as o}from"./index-B5ZZiHj2.js";const r=e=>o();export{r as u};
