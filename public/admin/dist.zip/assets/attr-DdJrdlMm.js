import{_ as m}from"./attr.vue_vue_type_script_setup_true_lang-CTaz8_bt.js";import"./index-B5ZZiHj2.js";export{m as default};
