import{i as o}from"./index-TUTPcGtB.js";const r=e=>o();export{r as u};
