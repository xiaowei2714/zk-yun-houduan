import{_ as m}from"./attr.vue_vue_type_script_setup_true_lang-fYXCWWof.js";import"./index-TUTPcGtB.js";export{m as default};
