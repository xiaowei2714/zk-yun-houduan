import{i as o}from"./index-B2xNDy79.js";const r=e=>o();export{r as u};
