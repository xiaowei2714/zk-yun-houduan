import{_ as m}from"./attr.vue_vue_type_script_setup_true_lang-BfAYpuFH.js";import"./index-B2xNDy79.js";export{m as default};
