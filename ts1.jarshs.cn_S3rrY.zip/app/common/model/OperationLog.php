<?php


namespace app\common\model;


class OperationLog extends BaseModel
{
}